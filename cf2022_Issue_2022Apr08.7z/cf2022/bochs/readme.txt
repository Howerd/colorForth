Real colorForth running slowly... 2022 Apr04
A tradeoff between working on (just about) any Windows PC against execution speed.

Double left click ( run ) go.bat to start the cf2022.img version of colorForth ( in the folder one level up )
in a bochs PC emulator. 
bochs is available from http://bochs.sourceforge.net/
Thank you to all the bochs developers :-)

Howerd Oakford  www.inventio.co.uk
